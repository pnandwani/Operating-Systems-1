#include "types.h"
#include "stat.h"
#include "user.h"

void test_loop(int loop)

{

    int fork_cnt = 0, wait_cnt = 0, exit_cnt = 0;
    int i = 0;

    reset_syscall_count();
    for(i=0; i < loop; i++)
    {

        int fret = fork();
        if (fret < 0)
        {
            printf(1, "fork() failed\n");
            exit();
        }
        else if (0 == fret)
        {
            exit();
        }
        else
        {
            wait();
        }
    }
    fork_cnt = get_syscall_count(0);
    wait_cnt = get_syscall_count(1);
    exit_cnt = get_syscall_count(2);
    printf(1, "Expected result : fork[%d] wait[%d] exit[%d] \n", loop, loop, loop);
    printf(1, "Actual result: fork[%d] wait[%d] exit[%d]\n", fork_cnt, wait_cnt, exit_cnt);
}

int main(void)
{
     printf(1, ">>> Test 1:\n");
     test_loop(5);
     return 0;
}